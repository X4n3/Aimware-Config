local function cancelAnim(event)
    local lpInfo = client.GetPlayerInfo(client.GetLocalPlayerIndex())
    if event:GetName()=="grenade_thrown" and lpInfo["UserID"]==event:GetInt("userid") then
        client.Command("lastinv", true)
    end
end

client.AllowListener( "grenade_thrown" )
callbacks.Register( "FireGameEvent", cancelAnim )