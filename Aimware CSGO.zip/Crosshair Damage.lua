local font_1 = draw.CreateFont("Verdana", 12)
local run_funcs = false
local weapons =
{
    "sniper";
    "scout";
    "hpistol";
    "asniper";
    "pistol";
    "knife";
    "smg";
    "rifle";
    "shotgun";
    "lmg";
    "shared";
}
local function condition_handler()
    lp = entities.GetLocalPlayer()
    screen_w, screen_h = draw.GetScreenSize()
    screen_w_h = screen_w * 0.5
    screen_h_h = screen_h * 0.5
    if lp ~= nil and lp:IsAlive() then
        lp_active_weapon = lp:GetPropEntity("m_hActiveWeapon")
        run_funcs = true
    else
        run_funcs = false
    end
end
callbacks.Register("Draw", condition_handler)
local function curr_weapon()
    if run_funcs then
        local current_weapon_type = lp_active_weapon:GetWeaponType()
        local current_weapon_id = lp_active_weapon:GetWeaponID()
        if current_weapon_id == 9 then
            return weapons[1]
        elseif current_weapon_id == 40 then
            return weapons[2]
        elseif current_weapon_id == 1 or current_weapon_id == 64 then
            return weapons[3]
        elseif current_weapon_id == 11 or current_weapon_id == 38 then
            return weapons[4]
        elseif current_weapon_type == 1 then
            return weapons[5]
        elseif current_weapon_type == 0 then
            return weapons[6]
        elseif current_weapon_type == 2 then
            return weapons[7]
        elseif current_weapon_type == 3 then
            return weapons[8]
        elseif current_weapon_type == 4 then
            return weapons[9]
        elseif current_weapon_type == 6 then
            return weapons[10]
        else
            return weapons[11]
        end
    end
end
local function draw_min_dmg()
    if run_funcs then
            if curr_weapon() ~= "knife" then
            local min_dmg = gui.GetValue("rbot.hitscan.accuracy." .. curr_weapon() .. ".mindamage")
            draw.Color(255,255,255)
            draw.SetFont(font_1)
            draw.TextShadow((screen_w_h + 10), (screen_h / 2 - 20), tostring(min_dmg))
            end
        end
    end
callbacks.Register("Draw", draw_min_dmg)