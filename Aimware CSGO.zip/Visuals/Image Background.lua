local LOGO=draw.CreateTexture(common.DecodePNG(http.Get("cdn.discordapp.com/attachments/1062301105293381682/1063102260181221436/output.png")))
local menu = gui.Reference("MENU")
local  a= 255
callbacks.Register("Draw", function()
    if menu:IsActive() then
        local menux,menuy = menu:GetValue()
        draw.Color(255, 255, 255,a);
        draw.SetTexture(LOGO)
        draw.FilledRect(menux+2,menuy+2,menux+798,menuy+598);
    end
end)
gui.SetValue("theme.ui2.lowpoly1",255, 255, 255, 0)
gui.SetValue("theme.ui2.lowpoly2",255, 255, 255, 0)
callbacks.Register( "Draw", function()
if menu:IsActive() then ay = 255 else ay =0 end
if ay ~= a then
if ay < a then a = a - 255
else a = a + 255
end end end)

AnLOGO = draw.CreateTexture(common.DecodePNG(http.Get("cdn.discordapp.com/attachments/1053326411957547061/1156235623003328522/330x192.png")))
gui.Reference("Menu"):SetIcon(AnLOGO, 0.85)