--由 wolf gang 团队开发 参考自 game sense havoc vision orb

local function clamp(val, min, max)
    return val > max and max or val < min and min or val
end

local function hsv(h, s, v, a)
    local r, g, b

    local i = math.floor(h * 6)
    local f = h * 6 - i
    local p = v * (1 - s)
    local q = v * (1 - f * s)
    local t = v * (1 - (1 - f) * s)

    i = i % 6

    if i == 0 then
        r, g, b = v, t, p
    elseif i == 1 then
        r, g, b = q, v, p
    elseif i == 2 then
        r, g, b = p, v, t
    elseif i == 3 then
        r, g, b = p, q, v
    elseif i == 4 then
        r, g, b = t, p, v
    elseif i == 5 then
        r, g, b = v, p, q
    end

    return r * 255, g * 255, b * 255, a * 255
end

local ui = {
    menu = gui.Reference("menu"),
    height = 0,
    ref = gui.Checkbox(gui.Reference("visuals", "other", "extra"), "", "Havoc Orb Pet Window", 1),
    main = gui.Window("esp.other.havocorb", "Havoc Orb Pet", 392, 290, 250, 260)
}

ui.on = gui.Checkbox(ui.main, "esp.other.havocorb.enable", "Enable script", 1)
ui.clr = gui.ColorPicker(ui.on, "clr", "c", 204, 167, 205, 255)
ui.rainbow = gui.Checkbox(ui.main, "esp.other.havocorb.rainbow", "Orb rainbow", 0)
ui.rainbow_speed = gui.Slider(ui.main, "esp.other.havocorb.rainbow.speed", "Rainbow speed", 1, 1, 10)
ui.radius = gui.Slider(ui.main, "esp.other.havocorb.radius", "Orb radius", 30, 10, 40)
ui.speed = gui.Slider(ui.main, "esp.other.havocorb.speed", "Orb speed", 6, 1, 10)

function ui.set()
    local fade = 1 * globals.FrameTime() * 500

    ui.height = ui.on:GetValue() and clamp(ui.height + fade, 75, 260) or clamp(ui.height - fade, 75, 260)

    ui.main:SetActive(ui.ref:GetValue() and ui.menu:IsActive())
    ui.main:SetHeight(ui.height)

    ui.clr:SetInvisible(ui.height < 76)
    ui.rainbow:SetInvisible(ui.height < 105)
    ui.rainbow_speed:SetInvisible(ui.height < 145)
    ui.radius:SetInvisible(ui.height < 195)
    ui.speed:SetInvisible(ui.height < 245)
end

local orb = {
    animator = {}
}

function orb.spawn_orb()
    local lp = entities.GetLocalPlayer()

    if not (lp and lp:IsAlive() and ui.on:GetValue()) then
        return
    end

    orb.origin = lp:GetAbsOrigin()

    orb.speed = ui.speed:GetValue() * 15

    table.insert(
        orb.animator,
        {
            orb.origin.x + math.cos(globals.TickCount() / orb.speed * math.pi) * 45,
            orb.origin.y + math.sin(globals.TickCount() / orb.speed * math.pi) * 45,
            orb.origin.z + 12
        }
    )

    if #orb.animator - 230 > 0 then
        table.remove(orb.animator, 1)
    end

    orb.start = #orb.animator - 100

    if not orb.animator[orb.start] then
        return
    end

    orb.vector = Vector3(unpack(orb.animator[orb.start]))

    orb.x, orb.y = client.WorldToScreen(orb.vector)

    orb.clr = ui.rainbow:GetValue() and {hsv(globals.RealTime() * ui.rainbow_speed:GetValue() * 0.1, 1, 1, 0.5)} or {ui.clr:GetValue()}

    orb.radius = gui.GetValue("esp.world.thirdperson") and ui.radius:GetValue() or ui.radius:GetValue() * 1.7

    if orb.x and orb.y then
        for i = 1, orb.start do
            orb.vector = Vector3(unpack(orb.animator[i]))

            orb.x, orb.y = client.WorldToScreen(orb.vector)

            orb.clr[4] = engine.GetPointContents(orb.vector) ~= 0 and 5 / 255 * i or 50 / 255 * i

            if orb.x and orb.y and orb.clr[4] ~= 0 then
                draw.Color(unpack(orb.clr))

                draw.FilledCircle(orb.x, orb.y, orb.radius)
            end
        end

        orb.clr[4] = engine.GetPointContents(orb.vector) ~= 0 and 50 or 255

        draw.Color(unpack(orb.clr))

        draw.FilledCircle(orb.x, orb.y, orb.radius)
    end
end

callbacks.Register(
    "Draw",
    function()
        ui.set()
        orb.spawn_orb()
    end
)
