local text_font = draw.CreateFont("Segoe Script", 38, 1000)
local function drawkeybinds(leaa)

    local LocalPlayer = entities.GetLocalPlayer();
    local a=LocalPlayer:GetWeaponInaccuracy() * 150
    local w, h = draw.GetScreenSize()

    if gui.GetValue("rbot.antiaim.base.rotation") <= -1 then
        local r, g, b = gui.GetValue("rbot.antiaim.extra.leaalist.kmainCol")
        draw.Color(r, g, b )
        draw.SetFont(text_font)
        draw.Text( w/2+10+leaaxy:GetValue()+a,h/2-10, "»")
        else
        local r, g, b = gui.GetValue("rbot.antiaim.extra.leaalist.ktextCol")
        draw.Color(r, g, b)
        draw.SetFont(text_font)
        draw.Text( w/2+10+leaaxy:GetValue()+a,h/2-10, "»")
	end
    if gui.GetValue("rbot.antiaim.base.rotation") >= 1 then
        local r, g, b = gui.GetValue("rbot.antiaim.extra.leaalist.kmainCol")
        draw.Color(r, g, b )
        draw.SetFont(text_font)
        draw.Text( w/2-27-leaaxy:GetValue()-a,h/2-10, "«")
     else
        local r, g, b = gui.GetValue("rbot.antiaim.extra.leaalist.ktextCol")
        draw.Color(r, g, b)
        draw.SetFont(text_font)
        draw.Text( w/2-27-leaaxy:GetValue()-a,h/2-10, "«")
	end
end
callbacks.Register("Draw", function()
    if leaalist:GetValue() == false then return end
    if not entities.GetLocalPlayer() or not entities.GetLocalPlayer():IsAlive() then return end
    draw.SetTexture( texture );
    drawkeybinds(leaa);
end)
function DrawUI()
leaalist = gui.Checkbox(gui.Reference("Ragebot","Anti-Aim","Extra"),"leaalist","AA Indicator",1);
kcolorPicker = gui.ColorPicker(leaalist, "kmainCol", "Main Colour", 252,210,254,255)
kcolorPicker2 = gui.ColorPicker(leaalist, "ktextCol", "Text Colour", 124,124,124,255)
leaaxy = gui.Slider( gui.Reference("Ragebot","Anti-Aim","Extra"),"xy","Interval", 40, 0, 300 )
end
DrawUI();

