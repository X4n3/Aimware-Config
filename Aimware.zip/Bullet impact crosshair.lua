local REF = gui.Reference( "Visuals", "Other", "Effects" )
local SHOW = gui.Checkbox( REF, "bulletimpacts", "Cross bullet impact point display", true )
SHOW:SetDescription("Show Crosspoints")
local COLOR = gui.ColorPicker( SHOW, "bulletimpacts.color", "cock", 255, 255, 255, 255 )
local bulletImpacts = {}
callbacks.Register( "Draw", function()
    if not SHOW:GetValue() then return end
    if not entities.GetLocalPlayer() then return end
    if table.getn(bulletImpacts) == 0 then return end

    if globals.CurTime() >= bulletImpacts[1][2] then
        table.remove(bulletImpacts, 1)
    end
    for i = 1, #bulletImpacts do
        local vecBullet = bulletImpacts[i][1]
        local LX, LY = client.WorldToScreen( vecBullet)
        if LX == nil or LY == nil then 
            goto continue 
        end
        draw.Color(COLOR:GetValue())
        draw.OutlinedRect( LX-4.5, LY-0.1,LX+4.5    ,LY+0.1 )
        draw.OutlinedRect( LX-0.1, LY+3.5,LX+0.1,LY-3.5 )
        ::continue::
    end
end )

callbacks.Register( "FireGameEvent", function(event)
    if event:GetName() ~= "bullet_impact" then return end
    if not SHOW:GetValue() then return end
    if client.GetPlayerIndexByUserID( event:GetInt( 'userid' ) ) ~= client.GetLocalPlayerIndex() then return end
    table.insert(bulletImpacts, {Vector3(event:GetFloat("x"), event:GetFloat("y"), event:GetFloat("z")), globals.CurTime() + 1.5})
end )
client.AllowListener( "bullet_impact" )