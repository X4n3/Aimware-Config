local group = gui.Reference("Ragebot", "Anti-Aim", "Advanced")
local radiussl = gui.Slider(group, "hi_rad", "Radius", 10, 10, 100)
local thicknesssl = gui.Slider(group, "hi_thickness", "Thickness", 49, 1, 50)
local bgcp = gui.ColorPicker(group, "hi_bgclr", "Background Color", 24,24,24,100)
local icp = gui.ColorPicker(group, "hi_iclr", "Indicator Color", 255,218,255,123)

local font = draw.CreateFont("Calibri", 22, 1000)

local function circle()

    local lp = entities.GetLocalPlayer()

    if lp ~= nil and gui.GetValue("rbot.master") then

        local headpos = lp:GetHitboxPosition(0)
        local origin = lp:GetAbsOrigin()
        local angle = (headpos - origin):Angles()
        local cam_angle = engine.GetViewAngles()
        local diff = cam_angle.y - angle.y

        local radius = radiussl:GetValue()
        local thickness = thicknesssl:GetValue()
        local bgr, bgg, bgb, bga = bgcp:GetValue()
        local ir, ig, ib, ia = icp:GetValue()
        if thickness > radius then
            thickness = radius
        end

        local ang = (diff * -1)/8
        if ang < 0 then ang = 22.5 + (22.5 - math.abs(ang)) end
        
        local x, y = draw.GetScreenSize()
        x = x/2
        y = y/2

        for steps = 1, 45, 1 do

            local sin_cur = math.sin(math.rad(steps * 8 + 180))
            local sin_old = math.sin(math.rad(steps * 8 - 8 + 180))
            local cos_cur = math.cos(math.rad(steps * 8 + 180))
            local cos_old = math.cos(math.rad(steps * 8 - 8 + 180))
            
            local cur_point = nil;
            local old_point = nil;

            cur_point = {x + sin_cur * radius, y + cos_cur * radius};    
            old_point = {x + sin_old * radius, y + cos_old * radius};

            local cur_point2 = nil;
            local old_point2 = nil;

            cur_point2 = {x + sin_cur * (radius - thickness), y + cos_cur * (radius - thickness)};    
            old_point2 = {x + sin_old * (radius - thickness), y + cos_old * (radius - thickness)};
            
            if steps >= ang - 2 and steps <= ang + 2 then
                draw.Color(ir, ig, ib, ia)
            else
                draw.Color(bgr, bgg, bgb, bga)
            end

            if ang - 2 < 0 and steps >= 45 + (ang - 2) then
                draw.Color(ir, ig, ib, ia)
            end
            if ang + 2 > 45 and steps <= (ang + 2) - 45 then
                draw.Color(ir, ig, ib, ia)
            end

            draw.Triangle(cur_point[1], cur_point[2], old_point[1], old_point[2], old_point2[1], old_point2[2])
            draw.Triangle(cur_point2[1], cur_point2[2], old_point2[1], old_point2[2], cur_point[1], cur_point[2])    
        
        end

        local offset = 0
        draw.SetFont(font)

    end
end

callbacks.Register("Draw", circle)
local drawetxtShadow_x = gui.Slider( gui.Reference( "Ragebot", "Anti-Aim", "Extra"  ), "drawetxtShadow_x", "X", 400 , 0 , 100 );local drawetxtShadow_y = gui.Slider( gui.Reference( "Ragebot", "Anti-Aim", "Extra"  ), "drawetxtShadow_y", "Y", 100 , 0 , 100 );drawetxtShadow_x:SetInvisible( true );drawetxtShadow_y:SetInvisible( true );